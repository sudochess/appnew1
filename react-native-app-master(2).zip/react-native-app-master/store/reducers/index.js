import { combineReducers } from 'redux';
import AppStore from './AppStore';

const reducers = combineReducers({
    AppStore
});

export default reducers;