import * as types from '../actions/ActionTypes';

const initialState = {
  lang: 'en'
}

export default function AppStore(state = initialState, action) {
  switch(action.type) {
    case types.SET_LANG:
      initialState.lang = action.lang
    //   state.lang = action.lang
      return initialState
    default:
      return state
  }
}