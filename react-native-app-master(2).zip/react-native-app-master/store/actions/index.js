import * as types from './ActionTypes';

export function setLang(lang) { 
  return {
    type: types.SET_LANG,
    lang: lang
  };
}