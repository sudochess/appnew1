import { packStrings } from '../constants/languagesPack'

export default getLangString = (code, str) => {
  // alert(packStrings[str])
  return packStrings[str] ? packStrings[str].find(item => item.locale === code).string : ''
}