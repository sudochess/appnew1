import React from 'react';
import { connect } from 'react-redux';
import { StyleSheet, Dimensions, ScrollView } from 'react-native';
import { Block, Button, Text, theme } from 'galio-framework';
import { ListItem } from 'react-native-elements';
import * as actions from '../store/actions';
import langList from '../constants/languages.json'

const { width } = Dimensions.get('screen');

class Language extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    const { style, navigation, lang } = this.props
    return (
      <Block flex style={[style, styles.lang]}>
        <ScrollView>
          <Text size={18} style={styles.langLabel}>Select a language you want</Text>
          {
            langList.map((l, i) => (
              <ListItem
                key={i}
                title={l.nativeName}
                topDivider
                chevron
                titleStyle={{fontWeight: lang === l.code ? 'bold' : '300' }}
                onPress={() => {
                  this.props.setLang(l.code)
                  navigation.navigate('Onboarding')
                }}
              />
            ))
          }
        </ScrollView>
      </Block>
    )
  }
}

const styles = StyleSheet.create({
  lang: {
    width: width,
    padding: theme.SIZES.BASE,
  },
  langLabel: {
    padding: 4,
  }
})

const mapStateToProps = (state) => {
  return { 
    lang: state.AppStore.lang
  };
};

const mapDispatchProps = (dispatch) => { 
  return {
    setLang: (lang) => { dispatch(actions.setLang(lang)) },
  };
};

export default connect(mapStateToProps, mapDispatchProps)(Language);