import React from 'react';
import { StyleSheet, Dimensions, ScrollView } from 'react-native';
import { Button, Block, Text, Input, theme } from 'galio-framework';

import { Icon, Delivery } from '../components/';

const { width } = Dimensions.get('screen');
import products from '../constants/products';

export default class Delivered extends React.Component {

  renderProducts = () => {
    const { navigation } = this.props;
    return (
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.products}>
        <Block flex>
          <Text center size={16} color="#000" style={{fontWeight: 'bold'}}>
            Mar 4 - Mar 10
          </Text>
          <Block flex row center style={{margin: 0}}>
            <Text size={30} color="#000" style={{fontWeight: 'bold', lineHeight: 30 }}>$</Text>
            <Text center size={100} color="#000" style={{fontWeight: 'bold', lineHeight: 100}}>
              707
            </Text>
            <Text size={30} color="#000" style={{fontWeight: 'bold', lineHeight: 30}}>.62</Text>
          </Block>
          <Block flex>
            <Text center size={20} color={theme.COLORS.BLOCK} style={{fontWeight: 'bold'}}>
              3 delivered orders
            </Text>
          </Block>
          <Block flex center>
            <Button
              shadowless
              style={styles.button}
              color={theme.COLORS.PRIMARY}
              onPress={() => navigation.navigate('Delivered')}>
              <Text size={16} style={styles.buttonText} color={theme.COLORS.WHITE}>
                {"Cash out $707.62".toUpperCase()}
              </Text>
            </Button>
          </Block>
        </Block>
        <Block flex>
          <Delivery product={products[0]} />
          <Delivery product={products[1]} />
          <Delivery product={products[2]} />
        </Block>
      </ScrollView>
    )
  }

  render() {
    return (
      <Block flex center style={styles.home}>
        {this.renderProducts()}
      </Block>
    );
  }
}

const styles = StyleSheet.create({
  home: {
    width: width,    
  },
  search: {
    height: 48,
    width: width - 32,
    marginHorizontal: 16,
    borderWidth: 1,
    borderRadius: 3,
  },
  header: {
    backgroundColor: theme.COLORS.WHITE,
    shadowColor: theme.COLORS.BLACK,
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowRadius: 8,
    shadowOpacity: 0.2,
    elevation: 4,
    zIndex: 2,
  },
  tabs: {
    marginBottom: 24,
    marginTop: 10,
    elevation: 4,
  },
  tab: {
    backgroundColor: theme.COLORS.TRANSPARENT,
    width: width * 0.50,
    borderRadius: 0,
    borderWidth: 0,
    height: 24,
    elevation: 0,
  },
  tabTitle: {
    lineHeight: 19,
    fontWeight: '300'
  },
  divider: {
    borderRightWidth: 0.3,
    borderRightColor: theme.COLORS.MUTED,
  },
  products: {
    width: width - theme.SIZES.BASE * 2,
    paddingVertical: theme.SIZES.BASE * 2,
  },
  button: {
    width: width * 0.6,
    marginTop: 10,
    marginBottom: 30,
    borderRadius: 30
  },
  buttonText: {
    fontWeight: 'bold'
  }
});
