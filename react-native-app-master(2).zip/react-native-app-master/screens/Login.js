import React from 'react';
import { connect } from 'react-redux';
import { ImageBackground, StyleSheet, StatusBar, Dimensions, Platform } from 'react-native';
import { Block, Button, Text, theme } from 'galio-framework';
import { Input, Icon } from 'react-native-elements';
// import Icon from 'react-native-vector-icons/FontAwesome';

const { height, width } = Dimensions.get('screen');

import materialTheme from '../constants/Theme';
import getLangString from '../constants/getLangString';

class Login extends React.Component {
  render() {
    const { navigation, lang } = this.props;
    const email = lang && getLangString(lang, 'email')
    const passwordString = lang && getLangString(lang, 'password')
    const forgot_password = lang && getLangString(lang, 'forgot_password')

    return (
      <Block flex style={styles.container}>
        <StatusBar barStyle="light-content" />
        <Block flex space="between" style={styles.padded}>
          <Block flex></Block>
          <Block flex space="between" style={{ zIndex: 2 }}>
            <Block>
              <Input placeholder={email[0] + email.slice(1)} inputStyle={styles.textInput} />
            </Block>
            <Block>
              <Input placeholder={passwordString[0] + passwordString.slice(1)}
                secureTextEntry={true}
                inputStyle={styles.textInput}
                rightIcon={
                  <Icon
                    name="panorama-fish-eye"
                    size={24}
                    color="white"
                  />
                }
              />
              <Text p style={styles.textLabel}>{forgot_password[0] + forgot_password.slice(1) + '?'}</Text>
            </Block>
            <Block center>  
              <Button
                shadowless
                style={styles.button}
                color={materialTheme.COLORS.BUTTON_COLOR}
                onPress={() => navigation.navigate('Home')}>
                {lang && getLangString(lang, 'singin').toUpperCase()}
              </Button>
            </Block>
          </Block>
          <Block flex></Block>
        </Block>
      </Block>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "linear-gradient(0deg, rgba(29,3,55,1) 0%, rgba(65,18,108,1) 34%, rgba(99,32,157,1) 100%)",
  },
  padded: {
    paddingHorizontal: theme.SIZES.BASE * 2,
    position: 'relative',
    bottom: theme.SIZES.BASE,
  },
  button: {
    width: width - theme.SIZES.BASE * 4,
    height: theme.SIZES.BASE * 3,
    shadowRadius: 0,
    shadowOpacity: 0,
  },
  textInput: {
    color: "white",
    height: theme.SIZES.BASE * 3,
  },
  textLabel: {
    color: "white",
    paddingTop: 4,
    textAlign: "right",
    fontSize: 14
  }
});

const mapStateToProps = (state) => {
  return { 
      lang: state.AppStore.lang
  };
};

export default connect(mapStateToProps)(Login);
