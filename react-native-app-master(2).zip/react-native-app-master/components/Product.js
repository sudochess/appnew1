import React from 'react';
import { withNavigation } from '@react-navigation/compat';
import { StyleSheet, Dimensions, Image, TouchableWithoutFeedback } from 'react-native';
import { Block, Text, theme, Button } from 'galio-framework';

const { width } = Dimensions.get('screen');

class Product extends React.Component {
  render() {
    const { product, style, priceColor, imageStyle } = this.props;
    const imageStyles = [styles.image, styles.fullImage, imageStyle];

    return (
      <Block flex card style={[styles.product, styles.shadow, style]}>
        <Block flex>
          <TouchableWithoutFeedback>
            <Block flex style={[styles.imageContainer, styles.shadow]}>
              <Image source={{ uri: product.image }} style={imageStyles} />
            </Block>
          </TouchableWithoutFeedback>
          <TouchableWithoutFeedback>
            <Block flex space="between" style={styles.productDescription}>
              <Text size={16} style={styles.productTitle} color={theme.COLORS.ERROR}>{product.title}</Text>
              <Text size={12} muted={!priceColor} color={priceColor}>(FLO984534)</Text>
              <Text size={20} style={styles.boldLabel}>{product.title} Contain</Text>
              <Text size={16} muted style={styles.description}>Pro Seller Pro Seller Pro Seller Pro Seller</Text>
              <Text size={16} muted style={styles.description}>Pro Seller Pro Seller Pro Seller Pro Seller</Text>
              <Text size={16} muted style={styles.description}>Pro Seller Pro Seller Pro Seller Pro Seller</Text>
              <Text size={16} muted style={styles.description}>Pro Seller Pro Seller Pro Seller Pro Seller</Text>
              <Text size={20} style={styles.boldLabel}>Size</Text>
              <Text size={16} muted style={styles.description}>Height : 30CM</Text>
              <Text size={16} muted style={styles.description}>Weight : 70CM</Text>
            </Block>
          </TouchableWithoutFeedback>
        </Block>
      </Block>
    );
  }
}

export default withNavigation(Product);

const styles = StyleSheet.create({
  product: {
    backgroundColor: theme.COLORS.WHITE,
    marginVertical: theme.SIZES.BASE,
    borderWidth: 0,
    minHeight: 114,
  },
  productTitle: {
    flex: 1,
    flexWrap: 'wrap',
  },
  boldLabel: {
    marginTop: 20,
    fontWeight: 'bold'
  },
  description: {
    marginVertical: 2
  },
  productDescription: {
    padding: theme.SIZES.BASE,
  },
  imageContainer: {
    elevation: 1,
  },
  image: {
    borderRadius: 3,
    marginHorizontal: theme.SIZES.BASE / 2,
    marginTop: -16,
  },
  horizontalImage: {
    height: 122,
    width: 'auto',
  },
  fullImage: {
    height: 215,
    width: width - theme.SIZES.BASE * 3,
  },
  shadow: {
    shadowColor: theme.COLORS.BLACK,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    shadowOpacity: 0.1,
    elevation: 2,
  },
  button: {
    marginVertical: theme.SIZES.BASE / 2,
    marginHorizontal: theme.SIZES.BASE
  }
});