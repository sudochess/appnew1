import React from 'react';
import { connect } from 'react-redux';
import { withNavigation } from '@react-navigation/compat';
import { StyleSheet, Dimensions, TouchableWithoutFeedback } from 'react-native';
import { Block, Text, theme, Button, Switch, Input } from 'galio-framework';
// import { Input } from 'react-native-elements';

import materialTheme from '../constants/Theme';
import getLangString from '../constants/getLangString';

const { width } = Dimensions.get('screen');

class OrderSet extends React.Component {
  state = {
    buttonShow: false,
    biggerMargin: false
  }
  toggleSwitch() {

  }
  render() {
    const { navigation, product, style, lang } = this.props;
    const { buttonShow, biggerMargin } = this.state
    const marginBottom = biggerMargin ? 140 : theme.SIZES.BASE

    return (
      <Block flex card style={[styles.product, styles.shadow, style, {marginBottom: marginBottom}]}>
        <Block flex>
          <Block flex space="between" style={styles.productDescription}>
            <Text size={20} style={styles.boldLabel}>{lang && getLangString(lang, 'delivered_address').toUpperCase()}</Text>
            <Text size={16} muted style={styles.description}>Pro Seller Pro Seller Pro Seller Pro Seller</Text>
            <Text size={16} muted style={styles.description}>Pro Seller Pro Seller</Text>
            <Text size={20} style={styles.boldLabel}>{lang && getLangString(lang, 'address_description').toUpperCase()}</Text>
            <Text size={16} muted style={styles.description}>Pro Seller Pro Seller Pro Seller Pro Seller</Text>
            <Text size={16} muted style={styles.description}>Pro Seller Pro Seller</Text>
            <Text size={20} style={styles.boldLabel}>{lang && getLangString(lang, 'delivered_datetime').toUpperCase()}</Text>
            <Text size={16} muted style={styles.description}>Pro Seller Pro Seller Pro Seller Pro Seller</Text>
            <Text size={16} muted style={styles.description}>Pro Seller Pro Seller</Text>
            <Text size={20} style={styles.boldLabel}>{lang && getLangString(lang, 'receiver_name_contact').toUpperCase()}</Text>
            <Text size={16} muted style={styles.description}>Pro Seller Pro Seller Pro Seller Pro Seller</Text>
            <Text size={16} muted style={styles.description}>Pro Seller Pro Seller</Text>
            <Text size={20} style={styles.boldLabel}>{lang && getLangString(lang, 'greeting_card_text').toUpperCase()}</Text>
            <Text size={16} muted style={styles.description}>Pro Seller Pro Seller Pro Seller Pro Seller</Text>
            <Text size={16} muted style={styles.description}>Pro Seller Pro Seller</Text>
            <Text size={16} muted style={styles.description}>Pro Seller Pro Seller</Text>
            <Text size={20} style={styles.boldLabel}>{lang && getLangString(lang, 'product_offer_price').toUpperCase()}</Text>
            <Block row flex style={styles.borderBox} space="between">
              <Block flex row space="between" style={styles.boxInputBlock}>
                <Input type='numeric' borderless style={styles.boxInput}>
                  <Text size={20} style={styles.boxLabel} color="#222">236.23</Text>              
                </Input>
                <Button
                  shadowless
                  style={styles.smallButton}
                  color={materialTheme.COLORS.MUTED}
                  // onPress={() => navigation.navigate('Home')}
                >
                  {"USD".toUpperCase()}
                </Button>
              </Block>
            </Block>
            <Text size={20} style={styles.boldLabel}>{lang && getLangString(lang, 'courier_fee').toUpperCase()}</Text>
            <Block row flex style={styles.borderBox} space="between">
              <Text size={18} style={styles.boxLabel} color="#000">Not free(if not free please)</Text>
              <Switch value={buttonShow} onChange={() => this.setState({buttonShow: !buttonShow})} />
            </Block>
            {buttonShow && <Block row flex style={styles.borderBox} space="between">
              <Block flex row space="between" style={styles.boxInputBlock}>
                  <Input type='numeric' borderless style={styles.boxInput} onFocus={() => this.setState({biggerMargin: !biggerMargin})} onBlur={() => this.setState({biggerMargin: !biggerMargin})}>
                    <Text size={20} style={styles.boxLabel} color="#222">36.2</Text>
                    {/* 36.2 */}
                  </Input>
                  <Button
                    shadowless
                    style={styles.smallButton}
                    color={materialTheme.COLORS.MUTED}
                    // onPress={() => navigation.navigate('Home')}
                  >
                    {"USD".toUpperCase()}
                  </Button>
                </Block>
            </Block>}
            <Block center>
              <Button
                shadowless
                style={styles.button}
                color={materialTheme.COLORS.BUTTON_COLOR}
                onPress={() => navigation.navigate('Home')}>
                {lang && getLangString(lang, 'send_offer').toUpperCase()}
              </Button>
              <Button
                shadowless
                style={styles.button}
                color={materialTheme.COLORS.ERROR}
                onPress={() => navigation.navigate('Home')}>
                {lang && getLangString(lang, 'cancel').toUpperCase()}
              </Button>
            </Block>
          </Block>
        </Block>
      </Block>
    );
  }
}

const styles = StyleSheet.create({
  product: {
    backgroundColor: theme.COLORS.WHITE,
    marginVertical: theme.SIZES.BASE,
    borderWidth: 0,
    minHeight: 114,
  },
  productTitle: {
    flex: 1,
    flexWrap: 'wrap',
  },
  boldLabel: {
    marginTop: 20,
    fontWeight: 'bold'
  },
  description: {
    marginVertical: 2
  },
  productDescription: {
    padding: theme.SIZES.BASE,
  },
  image: {
    borderRadius: 3,
    marginHorizontal: theme.SIZES.BASE / 2,
    marginTop: -16,
  },
  shadow: {
    shadowColor: theme.COLORS.BLACK,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    shadowOpacity: 0.1,
    elevation: 2,
  },
  button: {
    width: width - theme.SIZES.BASE * 4,
    marginVertical: theme.SIZES.BASE / 2,
  },
  borderBox: {
    marginVertical: theme.SIZES.BASE,
    borderWidth: 2,
    borderColor: theme.COLORS.MUTED
  },
  boxLabel: {
    padding: theme.SIZES.BASE / 2,
  },
  smallButton: {
    width: 80,
    borderRadius: 0
  },
  boxInputBlock: {
    
  },
  boxInput: {
    marginVertical: -8,
  }
});

const mapStateToProps = (state) => {
  return { 
      lang: state.AppStore.lang
  };
};

export default connect(mapStateToProps)(withNavigation(OrderSet));