import React from 'react';
import { withNavigation } from '@react-navigation/compat';
import { StyleSheet, Image, TouchableWithoutFeedback } from 'react-native';
import { Block, Text, theme, Button } from 'galio-framework';

import materialTheme from '../constants/Theme';
import  Icon  from '../components/Icon';

class Progress extends React.Component {
  render() {
    const { navigation, product, style, imageStyle } = this.props;
    const imageStyles = [styles.image, styles.horizontalImage, imageStyle];

    return (
      <Block flex card style={[styles.product, styles.shadow, style]}>
        <Block row flex>
          <TouchableWithoutFeedback>
            <Block flex style={[styles.imageContainer, styles.shadow]}>
              <Image source={{ uri: product.image }} style={imageStyles} />
            </Block>
          </TouchableWithoutFeedback>
          <TouchableWithoutFeedback>
            <Block flex space="between" style={styles.productDescription}>
              <Block flex>
                <Text size={14}>{product.title}</Text>
                <Text size={12} muted>Delivered date and time</Text>
                <Text size={12} color={theme.COLORS.ERROR}>18 January 2020</Text>
                <Text size={12} color={theme.COLORS.ERROR}>14:00 - 16:00</Text>
              </Block>
              <Block flex row space="between">
                <Text size={13} color={theme.COLORS.SUCCESS}>In Stock</Text>
                <Text size={13} muted color={theme.COLORS.ERROR}>${product.price}</Text>
              </Block>
            </Block>
          </TouchableWithoutFeedback>
        </Block>
        <Block center>
          <Button
            shadowless
            style={styles.button}
            color={materialTheme.COLORS.SUCCESS}
            onPress={() => navigation.navigate('Inprogress')}>
            <Block flex row space="between" style={styles.buttonTextBlock}>
              <Text size={18} center style={styles.buttonText} color={theme.COLORS.WHITE}>
                {"Change Status".toUpperCase()}
              </Text>
              <Icon size={16} name="shop" family="GalioExtra" color={theme.COLORS.WHITE} style={styles.buttonTextIcon} />
            </Block>
          </Button>
        </Block>
      </Block>
    );
  }
}

export default withNavigation(Progress);

const styles = StyleSheet.create({
  product: {
    backgroundColor: theme.COLORS.WHITE,
    marginVertical: theme.SIZES.BASE,
    borderWidth: 0,
    minHeight: 114,
  },
  productDescription: {
    padding: theme.SIZES.BASE / 2,
  },
  imageContainer: {
    elevation: 1,
  },
  image: {
    borderRadius: 3,
    marginHorizontal: theme.SIZES.BASE / 2,
    marginTop: -16,
  },
  horizontalImage: {
    height: 122,
    width: 'auto',
  },
  shadow: {
    shadowColor: theme.COLORS.BLACK,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    shadowOpacity: 0.1,
    elevation: 2,
  },
  button: {
    marginVertical: theme.SIZES.BASE / 2,
    marginHorizontal: theme.SIZES.BASE
  },
  buttonText: {
    flex: 1,
    fontWeight: 'bold'
  },
  buttonTextBlock: {
    width: '100%',
    marginVertical: theme.SIZES.BASE / 2,
  },
  buttonTextIcon: {
    marginRight: 8,
    lineHeight: 24
  }
});